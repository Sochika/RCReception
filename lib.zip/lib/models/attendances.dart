

class Attendances {
  final int? id;
   final int? memberID;
  final int? colombeID;
  final int eventID;



  Attendances(
      {this.id,
        required this.memberID,
        required this.eventID,
         this.colombeID,

      });

  factory Attendances.fromJson(Map<String, dynamic> json) => Attendances(
      id: json['id'],
    memberID : json['member_id'],
      eventID : json['events_id'] ?? 0,
      colombeID: json['colombe_id'],
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'member_id': memberID ,
    'colombe_id': colombeID,
    'events_id': eventID,
    };

// int save() {
//   return 1;
// }
}

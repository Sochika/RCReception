class Members {
  final int? id;
  final String firstName,
      middleName,
      lastName,
      keyNum,
      email,
      phoneNum;
  final int ab,
      gca;
  final String office,
      degree,
      gender;
   final int tmo;
  Members(
      {this.id,
      required this.firstName,
      required this.middleName,
      required this.lastName,
      required this.keyNum,
      required this.email,
      required this.phoneNum,
      required this.ab,
      required this.gca,
      required this.office,
      required this.degree,
      required this.tmo,
      required this.gender});
  // int abID = int.parse(ab?);
  // int gcaID = int.parse(gca);
  // int tmoID = int.parse(tmoController.text);

  factory Members.fromJson(Map<String, dynamic> json) => Members(
      id: json['id'],
      firstName: json['firstName'],
      middleName: json['middleName'] ?? '',
      lastName: json['lastName'],
      keyNum: json['keyNum'],
      email:json['email'] ?? '',
      phoneNum:json['phoneNumber'] ?? '',
      ab: json['ab_id'] ?? 0,
      gca: json['gca_id'] ?? 0,
      office: json['office'] ?? '',
      degree: json['degree'] ?? '',
      tmo: json['tmo'],
      gender: json['gender'] ?? '');

  Map<String, dynamic> toJson() => {
    'id': id,
    'firstName': firstName,
    'middleName': middleName,
    'lastName': lastName,
    'keyNum': keyNum,
    'email': email,
    'phoneNumber': phoneNum,
    'ab_id': ab,
    'gca_id': gca,
    'office': office,
    'degree': degree,
    'tmo': tmo,
    'gender': gender
  };

  
}

import 'dart:async';
import 'package:attendance/models/attendances.dart';
import 'package:attendance/models/attendancesRecords.dart';
import 'package:attendance/models/colombe.dart';
import 'package:attendance/models/event_types.dart';
import 'package:attendance/models/events.dart';
import 'package:attendance/models/settings.dart';
import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../models/membersRecords.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;
  static const int _version = 3;
  static const String _dbName = 'membersAttendance.db';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    WidgetsFlutterBinding.ensureInitialized();
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _dbName);
    // final documentsDirectory = await getApplicationDocumentsDirectory();

    return await openDatabase(
      path,
      version: _version,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {

    await db.execute('''
      CREATE TABLE IF NOT EXISTS gca(
        id INTEGER NOT NULL, 
        name TEXT NOT NULL, 
        PRIMARY KEY(id)
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS ab(
        id INTEGER NOT NULL,
        gca_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        PRIMARY KEY(id),
        CONSTRAINT gca_ab FOREIGN KEY (gca_id) REFERENCES gca (id)
      );
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS members(
        id INTEGER NOT NULL,
        firstName TEXT NOT NULL,
        lastName TEXT NOT NULL,
        middleName TEXT NOT NULL,
        keyNum TEXT NOT NULL,
        gender TEXT NOT NULL,
        phoneNumber TEXT,
        email TEXT,
        gca_id INTEGER,
        ab_id INTEGER,
        office TEXT,
        degree TEXT,
        affiliatedNum INTEGER NULL,
        natalDay TEXT,
        tmo INTEGER DEFAULT 0,
        late INTEGER DEFAULT 0,
        PRIMARY KEY(id),
        CONSTRAINT members_ak_1 UNIQUE(keyNum, gender),
        CONSTRAINT gca_members FOREIGN KEY (gca_id) REFERENCES gca (id),
        CONSTRAINT ab_members FOREIGN KEY (ab_id) REFERENCES ab (id)
      );
    ''');

    // Fixed attendances table syntax
    await db.execute('''
  CREATE TABLE IF NOT EXISTS attendances (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NULL,
  colombe_id INTEGER NULL,
  events_id INTEGER NOT NULL,
  entry_time TEXT DEFAULT CURRENT_TIMESTAMP,
  
  -- Foreign key constraints
  CONSTRAINT fk_event FOREIGN KEY (events_id) REFERENCES events(id) ON DELETE CASCADE,
  CONSTRAINT fk_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
  CONSTRAINT fk_colombe FOREIGN KEY (colombe_id) REFERENCES colombe(id) ON DELETE CASCADE,
  
  -- Exactly one attendee must be specified
  CONSTRAINT chk_attendee_type CHECK (
    (member_id IS NOT NULL AND colombe_id IS NULL) OR
    (member_id IS NULL AND colombe_id IS NOT NULL)
  )
);

-- Then create a separate unique index to enforce the constraint
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_attendance 
ON attendances(COALESCE(member_id, colombe_id), events_id)
WHERE member_id IS NOT NULL OR colombe_id IS NOT NULL;
    ''');

    await db.execute('''
     CREATE TABLE IF NOT EXISTS colombe (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        keyNum TEXT,
        firstName TEXT NOT NULL,
        middleName TEXT,
        lastName TEXT NOT NULL,
        gender TEXT DEFAULT 'Female',
        dob DATE NOT NULL,
         gca_id INTEGER,
        ab_id INTEGER,
        office TEXT DEFAULT 'Colombe',
        entry_time TEXT,
        CONSTRAINT firstName_lastName_middleName_unique 
          UNIQUE (firstName, lastName, middleName)
      );
    ''');


    await db.execute('''
    CREATE TABLE IF NOT EXISTS dues(
      id INTEGER NOT NULL,
      keyNum TEXT NOT NULL,
      gender TEXT NOT NULL,
      affiliatedNum INTEGER,
      affiliatedDate DATE,
      localDues INTEGER NULL,
      glDues DATE NULL,
      PRIMARY KEY(id),
      CONSTRAINT dues_keyNum_fk FOREIGN KEY (keyNum) REFERENCES members (keyNum),
      CONSTRAINT members_ak_2 UNIQUE(keyNum, gender),
      CONSTRAINT dues_affiliatedNum_fk FOREIGN KEY (affiliatedNum) REFERENCES members (affiliatedNum)
    );
  ''');

    await db.execute('''
    CREATE TABLE IF NOT EXISTS event_types(
      id INTEGER NOT NULL, 
      event_type TEXT NOT NULL, 
      PRIMARY KEY(id)
    );
  ''');

    await db.execute('''          
          CREATE TABLE IF NOT EXISTS events(
            id INTEGER NOT NULL,
            event_types_id INTEGER NOT NULL,
            speaker TEXT NOT NULL,
            time DATE NOT NULL,
            date DATE NOT NULL,
            PRIMARY KEY(id),
            CONSTRAINT event_types_events
              FOREIGN KEY (event_types_id) REFERENCES event_types (id)
          );
    ''');

    await db.execute('''
                            
          CREATE TABLE IF NOT EXISTS settings(
            id INTEGER NOT NULL,
            gca_id INTEGER NOT NULL,
            ab_id INTEGER NOT NULL,
            "userName" TEXT NOT NULL,
            max_desktop INTEGER NULL,
            PRIMARY KEY(id),
            CONSTRAINT gca_settings FOREIGN KEY (gca_id) REFERENCES gca (id),
            CONSTRAINT ab_settings FOREIGN KEY (ab_id) REFERENCES ab (id)
          );
         
    ''');

  //   await db.execute('''
  //   CREATE TRIGGER set_entry_time_on_insert
  //   AFTER INSERT ON attendances
  //   BEGIN
  //     UPDATE attendances
  //     SET entry_time = DATETIME('now')
  //     WHERE id = NEW.id;
  //   END;
  // ''');

    // Create other tables similarly...
    await _createRemainingTables(db);
    //
    // // Initial data setup
    await _initializeData(db);
    Future<T> _runWithDatabase<T>(Future<T> Function(Database db) operation) async {
      final db = await database;
      try {
        return await operation(db);
      } catch (e) {
        print('Database error: $e');
        rethrow;
      }
    }
  }

  Future<void> _createRemainingTables(Database db) async {

    // await db.execute('''
    //   CREATE TABLE attendances (
    //     id INTEGER PRIMARY KEY AUTOINCREMENT,
    //     keyNum TEXT NOT NULL,
    //     first_name TEXT NULL,
    //     last_name TEXT NULL,
    //     gender TEXT NOT NULL,
    //     events_id INTEGER NOT NULL,
    //     entry_time TEXT,
    //     CONSTRAINT events_attendances FOREIGN KEY (events_id) REFERENCES events (id),
    //     CONSTRAINT keyNum_keyNum FOREIGN KEY (keyNum) REFERENCES members (keyNum),
    //     CONSTRAINT keyNum_gender_events_id_unique UNIQUE (keyNum, gender, events_id)
    //   );
    // ''');

       // Create other tables...
  }

  Future<void> _initializeData(Database db) async {
    await db.execute('''
      INSERT INTO settings (id, gca_id, ab_id, userName, max_desktop)
      VALUES (1, 1, 1, 'SuchTree', 20);
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Handle database upgrades here
    if (oldVersion < 2) {
      // Migration for version 2
    }
    if (oldVersion < 3) {
      // Migration for version 3
    }
  }

  // Improved Settings Methods
  Future<int> setSettings(SettingsLoad setting) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.update(
        'settings',
        setting.toJson(),
        where: 'id = ?',
        whereArgs: [1],
      );
    });
  }

  Future<SettingsLoad?> getSetting() async {
    try {
      final db = await database;
      final result = await db.query(
        'settings',
        where: 'id = ?',
        whereArgs: [1],
        limit: 1,
      );
      return result.isNotEmpty ? SettingsLoad.fromJson(result.first) : null;
    } catch (e) {
      print('Error fetching setting: $e');
      return null;
    }
  }

  // Improved Member Methods
  Future<int> insertMember(Members member) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.insert(
        'members',
        member.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  // ========== Colombe Operations ==========
  Future<int> insertColombe(Colombe member) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.insert(
        'colombe',
        member.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  Future<List<Colombe>> getColombes() async {
    final db = await database;
    final results = await db.query('colombe');
    return results.map((map) => Colombe.fromJson(map)).toList();
  }

  // ========== Member Operations ==========
  // Future<int> insertMember(Members member) async {
  //   final db = await database;
  //   return await db.transaction((txn) async {
  //     return await txn.insert(
  //       'members',
  //       member.toJson(),
  //       conflictAlgorithm: ConflictAlgorithm.replace,
  //     );
  //   });
  // }

  Future<List<Colombe>> getAllColombes() async {
    final db = await database;
    final results = await db.query('colombe');
    return results.map((map) => Colombe.fromJson(map)).toList();
  }
  Future<List<Members>> getAllMembers() async {
    final db = await database;
    final results = await db.query('members');
    return results.map((map) => Members.fromJson(map)).toList();
  }

  Future<List<Members>> getMembersByKeyNum(String keyNum) async {
    final db = await database;
    final results = await db.query(
      'members',
      where: 'keyNum = ?',
      whereArgs: [keyNum],
    );
    return results.map((map) => Members.fromJson(map)).toList();
  }

  Future<List<Members>> getEventMembers(int eventId, String sortOrder) async {
    final db = await database;
    final order = sortOrder.toUpperCase() == 'ASC' ? 'ASC' : 'DESC';

    final results = await db.rawQuery('''
        SELECT 
    m.id,
    m.firstName,
    m.lastName,
    m.gender,
    'member' AS type
FROM attendances a
JOIN members m ON a.member_id = m.id
WHERE a.events_id = ?



ORDER BY a.id $order
    ''', [eventId]);

    return results.map((map) => Members.fromJson(map)).toList();
  }

  Future<List<AttendancesRecords>> getAttendanceMembers(int eventId, String sortOrder) async {
    final db = await database;
    final order = sortOrder.toUpperCase() == 'ASC' ? 'ASC' : 'DESC';

    final results = await db.rawQuery('''
      SELECT DISTINCT members.*, 'member' AS type
      FROM attendances
      JOIN members ON attendances.member_id = members.id
      WHERE attendances.events_id = ?
      
      UNION ALL
      
      -- For colombe
      SELECT DISTINCT colombe.*, 'colombe' AS type
      FROM attendances
      JOIN colombe ON attendances.colombe_id = colombe.id
      WHERE attendances.events_id = ?
      
      ORDER BY id $order
    ''', [eventId]);

    return results.map((map) => AttendancesRecords.fromJson(map)).toList();
  }

  Future<int> updateMember(Members member) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.update(
        'members',
        member.toJson(),
        where: 'id = ?',
        whereArgs: [member.id],
      );
    });
  }

  Future<int> updateColombe(Colombe member) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.update(
        'colombe',
        member.toJson(),
        where: 'id = ?',
        whereArgs: [member.id],
      );
    });
  }

  Future<int> deleteMember(int id) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.delete(
        'members',
        where: 'id = ?',
        whereArgs: [id],
      );
    });
  }

  // ========== Attendance Operations ==========
  Future<List<Attendances>> checkAttendance(Attendances attendee, int id) async {
    final db = await database;
    final results = await db.rawQuery(
      '''
      SELECT *
      FROM attendances
      WHERE events_id = ? AND  member_id  = ?
      ''',
      [attendee.eventID, id],
    );
    return results.map((map) => Attendances.fromJson(map)).toList();
  }

  Future<List<Attendances>> checkColombeAttendance(Attendances attendee, int id) async {
    final db = await database;
    final results = await db.rawQuery(
      '''
      SELECT *
      FROM attendances
      WHERE events_id = ? AND  colombe_id  = ?
      ''',
      [attendee.eventID, id],
    );
    return results.map((map) => Attendances.fromJson(map)).toList();
  }

  Future<int> markAttendance(Attendances attendance) async {
    try {
      final db = await database;
      return await db.transaction((txn) async {
        // First check if attendance already exists
        // final existing = await txn.query(
        //   'attendances',
        //   where: 'keyNum = ? AND events_id = ?',
        //   whereArgs: [attendance.memberID, attendance.eventID],
        // );
        //
        // if (existing.isNotEmpty) {
        //   return -1; // Special code for duplicate entry
        // }

        // Insert new attendance
        return await txn.insert(
          'attendances',
          attendance.toJson(), // Ensure this returns Map<String, dynamic>
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
    } catch (e) {
      print('Error in markAttendance: $e');
      rethrow;
    }
  }

  Future<int> deleteAttendance(Attendances attendee) async {
    final db = await database;
    return await db.transaction((txn) async {
     if(attendee.memberID != null){
       return await txn.delete(
         'attendances',
         where: 'events_id = ? AND member_id',
         whereArgs: [attendee.eventID, attendee.memberID],
       );
     }else{
       return await txn.delete(
           'attendances',
           where: 'events_id = ? AND colombe_id',
           whereArgs: [attendee.eventID, attendee.colombeID],);
     }
    });
  }

  // ========== Event Operations ==========
  Future<int> insertEvent(EventsDetails event) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.insert(
        'events',
        event.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  Future<int> updateEvent(int id, EventsDetails event) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.update(
        'events',
        event.toJson(),
        where: 'id = ?',
        whereArgs: [id],
      );
    });
  }

  Future<List<EventsDetails>> getEventById(int id) async {
    final db = await database;
    final results = await db.query(
      'events',
      where: 'id = ?',
      whereArgs: [id],
    );
    return results.map((map) => EventsDetails.fromJson(map)).toList();
  }

  Future<List<EventsDetails>> getAllEvents() async {
    final db = await database;
    final results = await db.rawQuery('''
      SELECT *
      FROM events
      ORDER BY id DESC
    ''');
    return results.map((map) => EventsDetails.fromJson(map)).toList();
  }

  Future<int> deleteEvent(int id) async {
    final db = await database;
    return await db.transaction((txn) async {
      final successEvent = await txn.delete(
        'events',
        where: 'id = ?',
        whereArgs: [id],
      );

      final successAttend = await txn.delete(
        'attendances',
        where: 'events_id = ?',
        whereArgs: [id],
      );

      return (successEvent > 0 && successAttend > 0) ? 1 : 0;
    });
  }

  // ========== Event Type Operations ==========
  Future<int> insertEventType(EventTypes eventType) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.insert(
        'event_types',
        eventType.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  Future<int> deleteEventType(int id) async {
    final db = await database;
    return await db.transaction((txn) async {
      return await txn.delete(
        'event_types',
        where: 'id = ?',
        whereArgs: [id],
      );
    });
  }

  // ========== Count Operations ==========
  Future<int> getAttendeeCount(int eventId, String gender) async {
    final db = await database;
    final count = await db.rawQuery('''
      SELECT COUNT(DISTINCT attendances.member_id) 
      FROM attendances 
      JOIN members ON attendances.member_id = members.id 
      WHERE attendances.events_id = ?
    ''', [eventId]);

    return Sqflite.firstIntValue(count) ?? 0;
  }

  Future<int> getMemberCount(String gender) async {
    final db = await database;
    final count = await db.rawQuery('''
      SELECT COUNT(*) 
      FROM members 
      WHERE gender = ?
    ''', [gender]);

    return Sqflite.firstIntValue(count) ?? 0;
  }

  Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
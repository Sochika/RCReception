
import 'package:attendance/models/colombe.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

import 'package:quickalert/quickalert.dart';
import 'package:sqflite/sqflite.dart';
import 'package:toggle_switch/toggle_switch.dart';

import '../../constants.dart';
import '../../data/sqlite.dart';


import 'components/header.dart';




class AddColombe extends StatelessWidget {
  const AddColombe({super.key});

  @override
  Widget build(BuildContext context) {
    return const AddColombeData();
  }
}

class AddColombeData extends StatefulWidget {
  const AddColombeData({super.key});

  @override
  State<AddColombeData> createState() => _AddColombeDataState();
}

class _AddColombeDataState extends State<AddColombeData> {
  @override
  Widget build(BuildContext context) {
    final db = DatabaseHelper();
    // final dba = db.open();
    // dba.

    final double width = MediaQuery.of(context).size.width;
    TextEditingController lNameController = TextEditingController();
    TextEditingController fNameController = TextEditingController();
    TextEditingController mNameController = TextEditingController();
    TextEditingController keyNumController = TextEditingController();
    TextEditingController abController = TextEditingController();
    TextEditingController gcaController = TextEditingController();
    TextEditingController dobController = TextEditingController();

    // print(lNameController.text);

    abController.text = '0';


    return SafeArea(
      child: SingleChildScrollView(
        primary: false,
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          children: [
            const Header(title: 'Add Colombe',),
            const SizedBox(height: defaultPadding),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,

              children: [
                // const ImportMembers(),
                const SizedBox(height: defaultPadding),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'First Name',),
                        controller: fNameController,
                        // textInputAction: TextInputAction.,
                      ),
                    ),

                    const SizedBox(width: defaultPadding),
                    SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'Middle Name'),
                        controller: mNameController,
                        // textInputAction: TextInputAction.,
                      ),
                    ),
                    const SizedBox(width: defaultPadding * 1.5),

                     SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'Last Name'),
                        controller: lNameController,
                        // textInputAction: TextInputAction.,
                      ),
                    ),


                    // Expanded(
                    //   flex: 5,
                    //   child: Column(
                    //     children: [
                    //       MyFiles(),
                    //       SizedBox(height: defaultPadding),
                    //       MarkAttend(),
                    //       SizedBox(height: defaultPadding),
                    //       RecentFiles(),
                    //       if (Responsive.isMobile(context))
                    //         SizedBox(height: defaultPadding),
                    //       if (Responsive.isMobile(context)) StorageDetails(),
                    //     ],
                    //   ),
                    // ),
                    // if (!Responsive.isMobile(context))
                    //   SizedBox(width: defaultPadding),
                    // // On Mobile means if the screen is less than 850 we don't want to show it
                    // if (!Responsive.isMobile(context))
                    //   Expanded(
                    //     flex: 2,
                    //     child: StorageDetails(),
                    //   ),
                  ],
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: TextField(
                        decoration: const InputDecoration(labelText: 'Key Number'),
                        keyboardType: TextInputType.number,
                        controller: keyNumController,
                        // textInputAction: TextInputAction.,
                      ),
                    ),





                    const SizedBox(width: defaultPadding),
                    SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: DropdownMenu(
                        width: width /4,
                        label: const Text('GCA'),
                        dropdownMenuEntries: const [
                          DropdownMenuEntry(value: '', label: ''),
                          DropdownMenuEntry(value: '1', label: 'Rivers'),
                        ],
                        onSelected: (value){
                          gcaController.text = value!;
                        },
                      ),
                    ),
                    const SizedBox(width: defaultPadding),
                    SizedBox(
                      height: 90.0,
                      width: width /4,
                      child: DropdownMenu(
                        width: width /4,
                        label: const Text('AB'),
                        dropdownMenuEntries: const [
                          // Text('Male'),
                          DropdownMenuEntry(value: '', label: ''),
                          DropdownMenuEntry(value: '7', label: 'Akhnaton Chapter'),
                          DropdownMenuEntry(value: '3', label: 'Arcane Pronaos'),
                          DropdownMenuEntry(value: '2', label: 'Dabaye Amaso Lodge'),
                          DropdownMenuEntry(value: '4', label: 'Ee-Dee Pronaos'),
                          DropdownMenuEntry(value: '5', label: 'St Germain Pronaos'),
                          DropdownMenuEntry(value: '1', label: 'Thales Lodge'),
                          DropdownMenuEntry(value: '6', label: 'The Rose Pronaos'),

                        ],
                        onSelected: (value){
                          abController.text = value!;
                        },
                        // controller: abController,
                      ),
                    ),

                  ],
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [


                    const SizedBox(width: defaultPadding),
                    SizedBox(
                      height: 90.0,
                      width: width / 4,
                      child: TextField(
                        controller: dobController, // Create a TextEditingController for this
                        decoration: const InputDecoration(
                          labelText: 'Date of Birth',
                          suffixIcon: Icon(Icons.calendar_today),
                        ),
                        readOnly: true, // This prevents the keyboard from appearing
                        onTap: () async {
                          DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime.now(),
                          );

                          if (pickedDate != null) {
                            String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
                            dobController.text = formattedDate;
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: defaultPadding),


                  ],
                ),
                SizedBox(width: width * 3 / 4 + (defaultPadding *2),

                    child: ElevatedButton(onPressed: () async {
                      if(fNameController.text == '' || lNameController.text == '' || keyNumController.text == '' || dobController.text == ''){
                        QuickAlert.show(
                          context: context,
                          type: QuickAlertType.error,
                          title: 'Oops...',
                          text: 'Please fill the required Data',
                        );
                      }else{
                        Colombe member = Colombe(firstName: fNameController.text, lastName: lNameController.text, middleName: mNameController.text, keyNum: keyNumController.text,  dob: dobController.text, ab: int.parse(abController.text), gca: int.parse(gcaController.text), office: 'Colombe', gender: 'Female',  );

                        // print(fNameController.text);
                        // print(member.lastName);
                        var idNum = await db.insertColombe(member);
                        print(idNum);
                        if (idNum > 0){
                          QuickAlert.show(
                            context: context,
                            type: QuickAlertType.success,
                            text: "Colombe's Data Entered Successfully!",
                          );
                         setState(() {
                           gcaController.text = '1';

                           abController.text = '';

                           dobController.text = '';
                         });
                        }else{
                          QuickAlert.show(
                            context: context,
                            type: QuickAlertType.error,
                            title: 'Oops...',
                            text: 'Sorry, something went wrong',
                          );
                        }

                      }

                      print(await getDatabasesPath());
                    }, child: const Text('Enter'),))
              ],
            )
          ],
        ),

    ),);

  }
}

